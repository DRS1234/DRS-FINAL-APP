package com.example.dstat.chapter5;

import android.app.ListActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String[] attraction={"Super Smash Bros(website)", "Unity Ball Game", "game1", "game2"};
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_main, R.id.travel, attraction));
        //setContentView(R.layout.activity_main);

    }
    public void onListItemClick(ListView l, View v, int position, long id){
            switch(position) {
                case 0:
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.smashbros.com/en_GB/")));
                    break;
                case 1:
                    startActivity(new Intent(MainActivity.this, game3.class));
                    break;
                case 2:
                    startActivity(new Intent(MainActivity.this, game1.class));
                    break;
                case 3:
                    startActivity(new Intent(MainActivity.this, game2.class));
                    break;
        }
    }
}
